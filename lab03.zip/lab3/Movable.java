import java.awt.*;
public interface Movable{
    public void move();
    public Point getLocation();
}