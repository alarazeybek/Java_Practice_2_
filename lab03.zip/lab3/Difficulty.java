public interface Difficulty{
    //1 is for Easy
    //2 is for Medium
    //3 is for Hard
    public void setDifficulty(int difficulty);
    public int getDifficulty();
}