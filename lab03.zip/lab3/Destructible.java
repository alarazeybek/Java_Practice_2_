interface Destructible{
    public boolean isDestroyed();
    public void takeDamage(double damage);
}